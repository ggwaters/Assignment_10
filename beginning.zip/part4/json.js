{"teammembers":[
	{
		"name":"Agnes",
		"title":"Vice President of Accounting",
		"bio":"With over 14 years of public accounting and business advisory service experience in the Tongas, Ecuador, Canada, Botswana and the US, Agnes is the most seasoned and diversed member of the Vecta Corp. team."
	},
	{
		"name":"Damon",
		"title":"Director of Development",
		"bio":"Damon is the Director of Development for Vecta Corp. Damon creates learning materials for Vecta Corp. as well as consulting for customers to integrate vSolutions into their production pipeline and business processes."
	},
	{
		"name":"Herbert",
		"title":"Director of Human Resources",
		"bio":"Herbert joined Vecta Corp. in October 1999 as Vecta Corp's first Human Resources Director. As such, he has overall human resources responsibility for Vecta Corp's operations worldwide."
	},
	{
		"name":"Mike",
		"title":"Vice President of Sales and Marketing",
		"bio":"Mike serves as the Vice President of Sales and Marketing for Vecta Corp. In this role Mike oversees Vecta Corp's marketing and corporate communications efforts worldwide."
	},
	{
		"name":"Wilbur",
		"title":"Founder and CEO",
		"bio":"While Wilbur is the founder and CEO of Vecta Corp, he is primarily known for being the pioneer and world leader of creating vSolutions."
	}
]}